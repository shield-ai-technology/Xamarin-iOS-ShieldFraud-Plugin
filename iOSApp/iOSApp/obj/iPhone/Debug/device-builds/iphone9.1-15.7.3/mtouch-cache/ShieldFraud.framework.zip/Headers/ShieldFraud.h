//
//  ShieldFraud.h
//  Shield
//
//  Created by Poe Poe Myint Swe on 9/1/20.
//  Copyright © 2020 Shield. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonHMAC.h>

//! Project version number for Shield.
FOUNDATION_EXPORT double ShieldVersionNumber;

//! Project version string for Shield.
FOUNDATION_EXPORT const unsigned char ShieldVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Shield/PublicHeader.h>


